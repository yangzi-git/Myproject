package shop.yangzi.com;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import shop.yangzi.com.DbUtil;

public class LoginDlg extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * �û�У�飬 �ɹ������û����ͣ�ʧ�ܷ���0
	 */
	private int vertifyUser(String name, String pwd) {
		// ִ�е�sql���
		String sql = "select type from t_user where name=? and password=?";
		int ret = 0;
		try {
			// ����һ���������ݿ�Ķ���
			Connection con = DbUtil.getConnection();
			// ����ִ��sql�Ķ���PreparedStatement
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, name);
			pst.setString(2, pwd);
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {
				ret = rs.getInt("type");
			}
			// �ر�����
			DbUtil.close(con, pst);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ret;
	}

	public LoginDlg(ShopView sv) {

		setTitle("�û���¼");
		setBounds(300, 200, 300, 150);
		Container cp = getContentPane();
		cp.setLayout(null);
		JLabel jl = new JLabel("�û�����");
		jl.setBounds(10, 10, 200, 18);
		final JTextField name = new JTextField();
		name.setBounds(80, 10, 150, 18);
		JLabel jl2 = new JLabel("���룺");
		jl2.setBounds(10, 50, 200, 18);
		final JPasswordField password = new JPasswordField();
		password.setBounds(80, 50, 150, 18);
		cp.add(jl);
		cp.add(name);
		cp.add(jl2);
		cp.add(password);
		JButton jb = new JButton("ȷ��");
		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String username = name.getText();
				String pwd = password.getText();

				if (username.trim().length() == 0 || new String(pwd).trim().length() == 0) {
					JOptionPane.showMessageDialog(null, "�û������벻����Ϊ��");
					return;
				}

				int type = vertifyUser(username, pwd);
				if ( type > 0) {
					sv.setbLogin(true);
					String usermsg;
					if(type == 1)
					    usermsg = "����Ա";
					else if(type ==2)
						usermsg = "����";
					else
					    usermsg = "��ͨ�û�";
					sv.setTitle(   usermsg + "����ҳ��");
					dispose();
				} else {
					JOptionPane.showMessageDialog(null, "�û������������");
				}
			}
		});
		jb.setBounds(80, 80, 60, 18);
		cp.add(jb);

		final JButton button = new JButton();
		button.setText("����");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				// TODO �Զ����ɷ������
				name.setText("");
				password.setText("");
			}
		});
		button.setBounds(150, 80, 60, 18);
		getContentPane().add(button);

		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setVisible(true);
	}
}
